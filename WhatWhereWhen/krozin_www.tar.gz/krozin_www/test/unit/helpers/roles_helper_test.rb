require 'test_helper'

class RolesHelperTest < ActionView::TestCase
end
