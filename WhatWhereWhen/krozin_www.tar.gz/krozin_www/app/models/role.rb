class Role < ActiveRecord::Base
  attr_accessible :name
  validates :name, :presence => {:message => "User must have a name"}, :uniqueness => {:message => "Role with this name is already exist"}
end
