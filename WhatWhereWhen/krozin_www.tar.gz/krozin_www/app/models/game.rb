class Game < ActiveRecord::Base
  attr_accessible :name, :date, :score, :state, :team, :question, :answer

  has_one :team
  has_many :questions
  has_many :answer, :through=> :questions
end
