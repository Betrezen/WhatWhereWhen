class User < ActiveRecord::Base
  attr_accessible :email, :name, :password, :role_id, :team
  validates :name, :presence => {:message => "User must have a name"}, :uniqueness => {:message => "User with this name is already exist"}
  has_many :teams, :through => :teamusers
end
