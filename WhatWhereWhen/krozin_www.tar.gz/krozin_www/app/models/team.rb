class Team < ActiveRecord::Base
  attr_accessible :capitan, :name, :user, :game_id
  has_many :users, :through => :teamusers
  belongs_to :game
end
