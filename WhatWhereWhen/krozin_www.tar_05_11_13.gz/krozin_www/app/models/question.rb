class Question < ActiveRecord::Base
  attr_accessible :status, :title, :ranswer, :user_id, :game_id

  belongs_to :user
  belongs_to :game
  has_many :answers
end
