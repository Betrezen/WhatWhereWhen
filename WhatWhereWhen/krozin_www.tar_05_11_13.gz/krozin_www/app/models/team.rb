class Team < ActiveRecord::Base
  attr_accessible :capitan, :name, :game_id, :Status, :TeamIP, :TSRegTeam, :TSRegSrv
  has_many :users, :through => :teamusers
  belongs_to :game
end
