class ApplicationController < ActionController::Base
  protect_from_forgery
  
  before_filter do |controller|
    Rails.logger.debug("Requested format=#{controller.request.format}")
  end

  private  
  def send_notification (url)
    begin
        Rails.logger.debug("url=#{url}")
        #url = "mail.ru"
        response = RestClient.get(url)
        #Rails.logger.debug("response=#{response}")
        #Rails.logger.debug(post.args[:payload][:params])
        #Rails.logger.debug("Response #{response}")
        #Rails.logger.debug("Response description: #{response.description}")
        #Rails.logger.debug("Response code: #{response.code}")
        #Rails.logger.debug("Response body: #{response.body}")
        #Rails.logger.debug("Response headers: #{response.headers.inspect}")
        #Rails.logger.debug( "Response raw_headers: #{response.raw_headers.inspect}")
        #Rails.logger.debug("Response cookies: #{response.cookies.inspect}")
        #Rails.logger.debug("Response net_http_res: #{response.net_http_res.inspect}")
        return response
    rescue RestClient::Exception => e
        puts "Response code: #{e.response}"
    rescue => e
        puts "Exception:#{e.inspect}"
    end    
  end
  
  def valid_json?(json_)
    JSON.parse(json_)
    return true
  rescue JSON::ParserError
    return false
  end
  
end
