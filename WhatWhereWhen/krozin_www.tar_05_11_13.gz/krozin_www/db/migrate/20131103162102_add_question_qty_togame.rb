class AddQuestionQtyTogame < ActiveRecord::Migration
  def change
    add_column :games, :QuestionQty, :int
  end
end
