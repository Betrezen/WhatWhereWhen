class Add4fieldsToTeams < ActiveRecord::Migration
  def change
    add_column :teams, :TeamIdPub, :string
    add_column :teams, :Status, :string
    add_column :teams, :TeamIP, :string
    add_column :teams, :TSRegTeam, :datetime
    add_column :teams, :TSRegSrv, :datetime
  end
end
