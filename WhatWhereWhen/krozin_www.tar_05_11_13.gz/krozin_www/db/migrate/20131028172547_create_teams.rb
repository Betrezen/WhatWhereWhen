class CreateTeams < ActiveRecord::Migration
  def change
    create_table :teams do |t|
      t.string :name
      t.integer :capitan
      t.belongs_to :game
      t.timestamps
    end
  end
end
