class CreateTeams < ActiveRecord::Migration
  def change
    create_table :teams do |t|
      t.string :name
      t.integer :capitan
      t.belongs_to :game
      create_table :teams_users do |t|
        t.belongs_to :team
        t.belongs_to :user
      end
      t.timestamps
    end
  end
end
