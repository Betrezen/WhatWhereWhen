class CreateQuestions < ActiveRecord::Migration
  def change
    create_table :questions do |t|
      t.string :title
      t.string :ranswer
      t.string :status
      t.belongs_to :game
      t.belongs_to :user
      t.timestamps
    end
  end
end
